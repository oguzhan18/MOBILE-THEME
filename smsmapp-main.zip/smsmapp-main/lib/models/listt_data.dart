class Trip {
  final String id;
  final List<String> categries;
  final String title;
  final String iamge;
  final String sel;

  const Trip({
    required this.id,
    required this.categries,
    required this.title,
    required this.sel,
    required this.iamge,
  });
}
