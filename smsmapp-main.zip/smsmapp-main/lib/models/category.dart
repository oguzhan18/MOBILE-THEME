class Category {
  final String id;
  final String titl;
  final String image;

  const Category({required this.id, required this.titl, required this.image});
}
